library(RJSONLD)

schools <- read.csv("schools.csv")
stanford <- schools$unicorns[schools$school=="Stanford"]
harvard <- schools$unicorns[schools$school=="Harvard"]
test = prop.test(stanford ,stanford + harvard, alternative="greater")
RJSONLD.export(test, 'test.jsonld')