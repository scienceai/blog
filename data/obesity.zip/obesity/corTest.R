obesity <- read.csv('obesity.csv')

test = cor.test(obesity$ObesityRate,obesity$MinutesSpentEating)

RJSONLD.export(test,'test.jsonld')